import logo from './logo.svg';
import './App.css';
import moment from 'moment';
import TransactionList from './components/TransactionList';
import AddItem from './components/AddItem';
import { useState, useEffect } from 'react';
import { Divider,Typography } from 'antd';

function App() {
  const [transactionData, setTransactionData] = useState([
    { id: 1, created: "01/02/2023 - 08:30", type: "income", amount: 50000, note: "allowance" },
    { id: 2, created: "01/02/2023 - 10:30", type: "expense", amount: 500, note: "อาหารเที่ยง" },
  ]);
  const [currentAmount ,setCurrentAmount] = useState(0)

  useEffect(() => {
    setCurrentAmount(
      transactionData.reduce(
      (sum, transaction) => sum = transaction.type === "income" ? sum + transaction.amount : sum - transaction.amount
      , 0)
    )
  }, [transactionData])

  const handleNoteChanged = (id, note) => {
    setTransactionData(
      transactionData.map(transaction => {
        const newNote = transaction.id === id ? note : transaction.note;
        transaction.note = newNote
        return transaction
      })
    )
  }

  const handleTransactionDeleted = (id) => {
    setTransactionData(transactionData.filter(data => data.id !== id))
  }

  const handleAddItem = itemData => {
    setTransactionData([...transactionData, {
      id: transactionData.length + 1,
      created: moment().format('DD/MM/YYYY - HH:mm'),
      ...itemData
    }])
  }

  return (
    <div className="App">
      <header className="App-header">
        <Typography.Title>Current Amount {currentAmount}</Typography.Title>
        <AddItem onItemAdded={handleAddItem}/>
        <Divider>บันทึก รายรับ-รายจ่าย</Divider>
        <TransactionList 
          data={transactionData} 
          onNoteChanged={handleNoteChanged}
          onTransactionDeleted={handleTransactionDeleted}/>
      </header>
    </div>
  );
}

export default App;
